import React from 'react';

interface NavbarProps {
  children?: React.ReactNode;
  className?: string;
  fixed?: boolean;
  transparent?: boolean;
}

/**
 * Navbar component for navigation headers
 */
export default function Navbar({ children, className = '', fixed = false, transparent = false }: NavbarProps) {
  const baseClasses = 'w-full';
  const positionClasses = fixed ? 'fixed top-0 left-0 right-0 z-50' : 'relative';
  const bgClasses = transparent ? 'bg-transparent' : 'bg-white';

  return (
    <nav className={`${baseClasses} ${positionClasses} ${bgClasses} ${className}`}>
      {children}
    </nav>
  );
}

interface NavbarBrandProps {
  children?: React.ReactNode;
  className?: string;
  href?: string;
}

export function NavbarBrand({ children, className = '', href = '/' }: NavbarBrandProps) {
  return (
    <a href={href} className={`flex items-center gap-2 font-semibold text-lg ${className}`}>
      {children}
    </a>
  );
}

interface NavbarLinksProps {
  children?: React.ReactNode;
  className?: string;
}

export function NavbarLinks({ children, className = '' }: NavbarLinksProps) {
  return (
    <div className={`flex items-center gap-6 ${className}`}>
      {children}
    </div>
  );
}

interface NavbarLinkProps {
  children?: React.ReactNode;
  className?: string;
  href?: string;
  active?: boolean;
}

export function NavbarLink({ children, className = '', href = '#', active = false }: NavbarLinkProps) {
  const activeClasses = active ? 'text-blue-600 font-medium' : 'text-gray-600 hover:text-gray-900';
  return (
    <a href={href} className={`text-sm transition-colors ${activeClasses} ${className}`}>
      {children}
    </a>
  );
}

interface NavbarActionsProps {
  children?: React.ReactNode;
  className?: string;
}

export function NavbarActions({ children, className = '' }: NavbarActionsProps) {
  return (
    <div className={`flex items-center gap-4 ${className}`}>
      {children}
    </div>
  );
}
