import React from 'react';

interface IconProps {
  name?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  onClick?: () => void;
}

/**
 * Generic Icon component - placeholder for icons detected in Figma
 * Replace with your preferred icon library (lucide-react, heroicons, etc.)
 */
export default function Icon({ size = 'md', className = '', onClick }: IconProps) {
  const sizes = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8',
    xl: 'w-12 h-12',
  };

  return (
    <span
      className={`inline-flex items-center justify-center ${sizes[size]} ${className}`}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
    >
      {/* Placeholder - replace with actual icon implementation */}
      <svg
        className="w-full h-full"
        fill="none"
        stroke="currentColor"
        viewBox="0 0 24 24"
        xmlns="http://www.w3.org/2000/svg"
      >
        <rect x="3" y="3" width="18" height="18" rx="2" strokeWidth="2" />
      </svg>
    </span>
  );
}
