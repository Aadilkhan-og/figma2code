import React from 'react';
import { Button, Icon, Navbar, Card, Input } from '@/components/ui';

interface GeneratedPageProps {
  textOrders: string; // Default: "Orders"
  textSubscribe: string; // Default: "Subscribe"
  color?: string; // Default: "#404040"
}

const AddTicketSideSheet: React.FC<GeneratedPageProps> = (props) => {
  return (
    <div className="flex flex-col bg-white border border-black rounded-3xl shadow-2xl overflow-hidden">
      <div className="flex flex-row gap-2.5 justify-between items-center p-5 border border-black">
        <span className="bg-[${props.color}] text-base font-medium leading-snug tracking-widest w-[52px] h-[11px]">{props.textOrders}</span>
        <div className="flex flex-row gap-5 justify-center items-center">
          <div className="flex flex-row gap-[7px] items-center py-[3px] px-0.5 overflow-hidden">
            <Icon className="bg-[${props.color}] w-[18px] h-4" />
            <span className="bg-[${props.color}] text-[13px] font-normal leading-snug tracking-widest w-[59px] h-[9px]">{props.textSubscribe}</span>
          </div>
          <div className="flex flex-col gap-2.5 justify-center items-center py-[3px] px-0.5 overflow-hidden">
            <Icon className="border-[1.6666666269302368px] border-[${props.color}] w-[13.387666702270508px] h-[13.336437225341797px]" />
          </div>
          <div className="flex flex-col gap-2.5 justify-center items-center py-[3px] px-0.5 overflow-hidden">
            <Icon className="bg-[${props.color}] w-[14px] h-[14px]" />
          </div>
          <div className="flex flex-col gap-2.5 py-[3px] px-0.5 overflow-hidden">
            <Icon className="bg-[${props.color}] w-[14px] h-[14px]" />
          </div>
        </div>
      </div>
      <div className="flex flex-col gap-[35px] pt-[35px] pr-[60px] pb-[60px] pl-[60px]">
        {/* Content goes here */}
      </div>
    </div>
  );
};

export default AddTicketSideSheet;