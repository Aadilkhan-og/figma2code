import React from 'react'
import GeneratedPage from './pages/GeneratedPage'

function App() {
  return <GeneratedPage textOrders="Orders" textSubscribe="Subscribe" />
}

export default App